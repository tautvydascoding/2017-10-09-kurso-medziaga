
<?php
/*
  * Template Name: Paptastas su dviem linijom
  *
  */

get_header();

?>



    <?php
    // meniu atsiras cia                   !!!! primary_pagrindinis - turi sutapti pavadinimas su funcitons.php faile aprasytu
    wp_nav_menu( array('theme_location' => 'primaryPagrindinis'));
    ?>

    <h1>About psulapiukas - su unikaliu dizianu</h1>

    <?php

    if(have_posts()) :
        while(have_posts()) :
            the_post(); ?>



            <h2> <?php the_title(); ?>  </h2>
            <hr>
            <hr>
            <p>  <?php   the_content();  ?> </p>

            <?php
        endwhile;
    endif;
    ?>


<?php get_footer(); ?>

