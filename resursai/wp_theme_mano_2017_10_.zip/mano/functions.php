<?php




// CSS ir JS mano failu idejimas i mano theme'a
function failuParuosimas() {

	// 				  my name            path to css file							 dependencies version  @media kur naudoti
	wp_enqueue_style('customstyle', get_template_directory_uri() . '/css/custom.css', array(),    '1.0.0',   'all');
	// 				  my name            path to css file							 dependencies version     ar footer
	wp_enqueue_script('customscript', get_template_directory_uri() . '/js/custom.js', array(),    '1.0.0',   'true');
}

// kada paleisti musu f-ja "ready_files" ? 
add_action('wp_enqueue_scripts', failuParuosimas);


// Menu
function menuParuosimas() {
	add_theme_support('menus');
	//                  Menu Name                  Description
	register_nav_menu('primaryPagrindinis', 'Meniu atvaizduojamas virsuje psulapio'); // atsiras Appearance->menu  checkbox - Theme Location
}
add_action('after_setup_theme', 'menuParuosimas');